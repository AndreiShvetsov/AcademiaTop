import { Component } from '@angular/core';

@Component({
  selector: 'app-info-autor',
  templateUrl: './info-autor.component.html',
  styleUrls: ['./info-autor.component.css']
})
export class InfoAutorComponent {

}
